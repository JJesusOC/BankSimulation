import java.util;
import java.io;
package simulator;

public class BankSimulation implements simulators
  
{

class BankSimulation
  {

    //parameters requiered for simulation
    private int numberTellers, customerLimit;
    private int simulationTime, dataSource;
    private int potentialArrivals, maxTransactionsTimes;

    //data from source given for simulation
    private int numberLeave, numberServed, totalWaitTime;

    private int customerID;
    private ServiceArea servicearea;
    private Scanner dataFile;

    private boolean newArrival;
    private int transactionTime;

    //initialize the required data for simulation
    private BankSimulation()
    {
      numberLeave = 0;
      numberserved = 0;
      totalWaitTime = 0;
      customerID = 0;
    }

    //introduction and setup for data information
    private void setParameters()
    {
      Scanner input = new Scanner(System.in);
      System.out.println("\n\t***  Bank Simulation Parameters  ***\n");

      do
        {
          System.out.println("Enter the time for the bank simulation: ");
          simulationTime = input.nextInt();
        }
      while (simulationTime > 1000 || simulationTime < 0);

      do
        {
          System.out.println("Enter the maximum time for transactions with customers: ");
          maxTransactionsTimes = input.nextInt();
        }
        while (maxTransactionsTimes > 500 || maxTransactionsTimes <= 0);

      do
        {
          System.out.println("Enter possible arrivals of new customers: ");
          potentialArrivals = input.nextInt();
        }
        while (potentialArrivals > 100 || potentialArrivals <= 0);

      do
        {
          System.out.println("Enter the number of Tellers:");
          numberTellers = input.nextInt();
        }
        while ( numberTellers > 10 || numberTellers < 0);

      do
        {
          System.out.println("Enter the limit for customers:");
          customerLimit = input.nextInt();
        }
        while ( customerLimit > 50 || customerLimit < 0);

      do
        {
          System.out.println("Enter 1 to recieve data from a file.");
          System.out.println("Enter 0 to recieve randomized data.");
          dataSource = input.nextInt();
        }
        while (dataSource > 1 || dataSource < 0);

      if (dataSource == 1)
      {
        System.out.println("Enter file name to read data: ");
        try
          {
            dataFile = newScanner (new File(input.next()) );
          }
        catch(FilenotFoundExpedtion ex)
          {
            System.out.println("File not found. Now randomizing.");
            dataSource = 0;
          }
      }
      else 
      {
        System.out.println("Randomizng data now.");
      }

      input.close();
      dataRandom = new Random();
    }

//recieves data from any new customers
  private void getCustomerData()
    {
      if (dataSource == 1)
      {
        int data1,data2;
        data1 = data2 = 0;

        if (dataFile.hasNextInt())
        {
          data1 = dataFile.nextInt();
          data2 = dataFile.nextInt();
        }
        potentialArrivals = (((data1%100) + 1) <= potentialArrivals);
        transactionTime = (data2%maxTransactionsTimes)+1;
      }
    }

//begin bank simulation
  private void doSimulation()
    {
      System.out.println("\n\t*** Begin Simulation ***\n");
      servicearea = new ServiceArea (numberTellers, customerLimit, 1);
      
      for (int currentTime = 0; currentTime < simulationTime; currentTime++)
        {
          system.out.println("______");
          system.out.println("Time: " + (currentTime+1));
          system.out.println("Queue: " + servicearea.numWaitingCustomers()             + "/" + customerLimit);

          totalWaitTime = (servicearea.numWaitingCustomers() > 0) ? totalWaitTime+1 : 0;

//proceed to document events in simulation

//any new customers?
getCustomerData();

if (anyNewArrival)
{
  customerID++;
  system.out.println("\t Customer #" + customerID + "arrives with transaction time " + transactionTime + " unit(s).");

  if(servicearea.isCustomerQTooLong())
  {
    System.out.println("\t Customer queue is full. Customer #" + customerID + " leaves.");
    numGoaway++;
  }
  else
  {
    system.out.println("\t Customer #" + customerID + " waits in the customer queue.");
    servicearea.insertCustomerQ( new Customer(customerID, transacrionTime, currentTime));
  }
}
  else
  {
    system.out.println("\t No new customers have entered!");
  }

//This section begins to free up number of tellers
// as the number of customers begin to drop.

while(servicearea.numBusyTellers() > 0 && servicearea.getFrontBusyTeller().getEndBusyIntervalTime() == currentTime)
  {
    Teller teller = servicearea.removeBusyTeller();
    teller.busyToFree();
    servicearea.inserFreeTeller(teller);

    system.out.println("\t Customer# " + teller.getCustomer().getCustomerID() + "is done.");
    system.out.println("\t Teller # " + teller.getTellerID() + "is able to leave posiition."); 
  }

//If new customers come in, provide to tellers to assist

while(servicearea.numFreeTellers() > 0 && servicearea.numWaitingCustomers() > 0)
  {
    Customer customer = servicearea.removeCustomerQ();
    Teller teller = servicearea.removeFreeTellerQ();
    teller.freeToBusy( customer, currentTime);
    servicearea.insertBusyTellerQ(teller);
    numServed++;
    system.out.println("\t Customer # " + customerID.getCustomerID() + " gets teller # " + teller.getTellerID() + " for " + customer.getTransactionTime() + " unit(s).");
  }
   }
    }
//Begin to end the simulation
//provide simulation results

private void printStatistics()
    {
      system.out.println("\n ___________\n");
      system.out.println("\t*** End of simulation results ***\n\n");
      system.out.println("\t\t# Total number of customers that arrived: "+ customerID);
      system.out.println("\t\t# Customers that left: " + numGoaway);
      system.out.println("\t\t# Customers served: " + numberServed);

      system.out.println("\n\n\t*** Current tellers information: ***\n\n");
      servicearea.printStatisics();

      system.out.println("\n\n\t Total waiting time : " + totalWaitingTime);
      double averageWaitingTime = ( servicearea.emptyCustomerQ())
          ? 0.0 : (double)totalWaitingTime / servicearea.numWaitingCustomers();
      system.out.println("\t\t Average waiting time: %.2f\n", averageWaitingTime);

      system.out.println("\n\n\t*** Busy tellers information. ***\n\n");
      if (!servicearea.emptyBusyTellerQ())
      {
        while (servicearea.numBusyTellers() > 0)
          {
            Teller teller = servicearea.removeBusyTellerQ();
            teller.setEndIntervalTime(simulationTime, 1);
            teller.printStatistics();
          }
      } 
      
      else
      {
        system.out.println("\t\t No free tellers available. \n");
      }
      system.out.println();
      }

    public static void main(String[] args)
    {
    BankSimulation runBankSimulation = new BankSimulation();
    runBankSimulation.setupParameters();
    runBankSimulation.doSimulation();
    runBankSimulation.printStatistics();
    }
  
  
  
//End of Bank Simulation


//Customer section for lab


class Customer
  {
    private int customerID;
    private int transactionTime;
    private int arrivalTime;

    Customer()
    {
      this(1,1,1);
    }

    Customer( int customerid, int transactiontime, int arrivaltime)
    {
      customerID = customerid;
      transactionTime = transactiontime;
      arrivalTime = arrivaltime;
    }

    int getTransactionTime()
    {
      return transactionTime;
    }
    
    int getArrivalTime()
    {
      return arrivalTime;
    }

    int getCustomerID()
    {
      return customerID;
    }

    public string toString()
    {
      return ""+customerID+" : "+transactionTime+":"+arrivalTime;
    }

    public static void main(String[] args)
    {

      Customer mycustomer = new Customer(10,20,30);
      system.out.println("Customer information:" + mycustomer);
    }
  }
  }


//Teller section for lab
class Teller
  {
  private int startTime;
  private int endTime;

  private int tellerID;
  private Customer currentCustomer;

  private int totalFreeTime;
  private int totalBusyTime;
  private int totalCustomers;

  Teller()
    {
      this(1);
    }
  Teller(int tellerid)
    {
      tellerID = tellerid;
    }

    int getTellerID()
    {
      return tellerID;
    }
    Customer getCustomer()
    {
      return currentCustomer;
    }

    int getEndBusyIntervalTime()
    {
      return endTime;
    }

    void freeToBusy (Customer currentCustomer, int currentTime)
    {
      totalFreeTime += (currentTime -startTime);
      startTime = currentTime;
      endTime = startTime + currentCustomer.getTransactionTime();
      this.currentCustomer = currentCustomer;
      totalCustomers++;
    }

    Customer busyToFree()
    {
      totalBusyTime += (endTime - startTime);
      startTime = endTime;
      return currentCustomer;
    }

    void setEndIntervalTime (int endssimulationtime, int intervalType)
    {
      endTime = endsimulationtime;
      if(intveralType == 0)
      {
        totalFreeTime += endTime - startTime;
      }
      else
      {
        totalBusyTime += endTime - startTime;
      }
    }

    void printStatistics ()
    {
      system.out.println( "\t\t Teller ID: " + tellerID);
      system.out.println("\t\t Total free time: " + totalFreeTime);
      system.out.println("\t\t Total busy time: " + totalBusyTime);
      system.out.println("\t\t Total number of Customers: " + totalCustomers);

      if (totalCustomers > 0)
      {
        system.out.format("\t\t Average transaction time: %.2\n");
        ((totalBusyTime)*1.0) = (totalCustomers);
      }
      system.out.println();
    }
    
  }
  }